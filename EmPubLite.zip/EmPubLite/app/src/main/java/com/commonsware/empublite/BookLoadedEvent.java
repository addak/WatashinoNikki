package com.commonsware.empublite;

public class BookLoadedEvent {
    BookContents mContents;

    public BookLoadedEvent(BookContents contents){
        mContents = contents;
    }

    public BookContents getContents(){  return mContents; }
}
