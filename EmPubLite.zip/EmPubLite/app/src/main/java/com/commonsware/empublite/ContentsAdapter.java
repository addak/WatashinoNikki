package com.commonsware.empublite;


;

import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class ContentsAdapter extends FragmentStatePagerAdapter {

    final BookContents mBookContents;

    public ContentsAdapter(FragmentManager fm, BookContents contents){
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mBookContents = contents;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        String path = mBookContents.getChapterFile(position);

        return SimpleContentFragment.newInstance("file:///android_asset/book/" + path);
    }

    @Override
    public int getCount() {
        return mBookContents.getChapterCount();
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mBookContents.getChapterTitle(position);
    }
}
