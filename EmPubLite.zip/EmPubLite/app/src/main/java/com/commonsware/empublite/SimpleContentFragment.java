package com.commonsware.empublite;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SimpleContentFragment extends Fragment {

    private static final String KEY_FILE="file";

    WebView contentWebView;

    public static SimpleContentFragment newInstance(String file) {
        
        Bundle args = new Bundle();
        args.putString(KEY_FILE, file);

        SimpleContentFragment fragment = new SimpleContentFragment();
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_content, container, false);

        contentWebView = v.findViewById(R.id.content_view);
        contentWebView.getSettings().setJavaScriptEnabled(true);
        contentWebView.getSettings().setSupportZoom(true);
        contentWebView.getSettings().setBuiltInZoomControls(true);
        contentWebView.loadUrl(getPage());

        return v;
    }

    @Override
    public void onPause() {
        contentWebView.onPause();
        super.onPause();
    }

    @Override
    public void onResume() {
        contentWebView.onResume();
        super.onResume();
    }

    private String getPage(){
        return getArguments().getString(KEY_FILE);
    }
}
