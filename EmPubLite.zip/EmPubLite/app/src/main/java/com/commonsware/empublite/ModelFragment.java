package com.commonsware.empublite;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.gson.Gson;

import org.greenrobot.eventbus.EventBus;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.atomic.AtomicReference;

public class ModelFragment extends Fragment {
    AtomicReference<BookContents> mContents = new AtomicReference<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if( mContents.get() == null) new LoadThread(context.getAssets()).start();
    }

    public BookContents getBook(){
        return mContents.get();
    }


    public class LoadThread extends Thread{
        AssetManager mAssetManager;

        public LoadThread(AssetManager am){
            super();
            mAssetManager = am;
        }

        @Override
        public void run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND);
            Gson gson = new Gson();

            try {
                InputStream is = mAssetManager.open("book/contents.json");
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));

                mContents.set( gson.fromJson(reader, BookContents.class) );

                EventBus.getDefault().post(new BookLoadedEvent(getBook()));

            }catch (IOException e){
                Log.e(getClass().getSimpleName(), "Exception parsing JSON", e);
            }
        }
    }
}
