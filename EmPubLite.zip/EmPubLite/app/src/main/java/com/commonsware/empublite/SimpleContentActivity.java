package com.commonsware.empublite;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;


public class SimpleContentActivity extends FragmentActivity {
    public static final String EXTRA_FILE = "file";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        if (getSupportFragmentManager().findFragmentById(R.id.fragment_container)== null) {
            String file=getIntent().getStringExtra(EXTRA_FILE);

            Fragment f=SimpleContentFragment.newInstance(file);
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.fragment_container, f).commit();
        }
    }
}
